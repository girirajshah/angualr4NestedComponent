import { Component } from '@angular/core';

@Component({
    selector: 'superhero-app',
    template: `
        <div>
            <h1>{{pageTitle}}</h1>
            <super-heroes></super-heroes>
        </div>
     `
})
export class AppComponent {
    pageTitle: string = "India's Pride";
}
