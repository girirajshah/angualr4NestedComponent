import { Component} from "@angular/core";

@Component({
    moduleId : module.id,
    selector : 'super-heroes',
    templateUrl : 'hero-list.component.html'
})

export class HeroListComponent {
    
}